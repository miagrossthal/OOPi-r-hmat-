package com.example.oop_graafika;

/**************************************************************************
 * Objektorienteeritud programmeerimine LTAT.03.003 2025/2026 kevadsemester
 * Rühmatöö nr 2
 * Teema: Matemaatika programm JavaFX graafilise kasutajaliidesega
 * Autorid: Mia Grossthal, Joosep-Gre Kallaste
 **************************************************************************/

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;

/**
 * JavaFX rakenduse põhiklass.
 * Klass vastutab kogu graafilise kasutajaliidese loomise ja juhtimise eest.
 * Siin luuakse vaated, menüü, kordamiskaardid, testivaade, tulemuste vaade
 * ning klaviatuuri- ja hiiresündmused.
 */
public class GraafilineRakendus extends Application {

    // Hoiab kordamise andmeid teemade kaupa.
    // Võti on teema nimi ja väärtus on selle teema kordamismaterjalide nimekiri.
    private final Map<String, List<KordamisTeema>> kordamiseAndmed = new LinkedHashMap<>();

    // Hoiab testi andmeid teemade kaupa.
    // Võti on teema nimi ja väärtus on selle teema testiküsimuste nimekiri.
    private final Map<String, List<TestiTeema>> testiAndmed = new LinkedHashMap<>();

    // Objekt, mille abil salvestatakse ja loetakse testitulemusi failist.
    private final TulemusteHaldur tulemusteHaldur = new TulemusteHaldur();

    // Rakenduse põhikonteiner, millel on ülemine, vasak, keskne ja alumine osa.
    private BorderPane juur;

    // Alumine riba, kus kuvatakse olekuteksti ja vajadusel tulemuste nuppu.
    private HBox alumineRiba;

    // Tekst, mis kuvab kasutajale juhiseid, õnnestumisi või veateateid.
    private Label olekuTekst;

    // Nupp, mis ilmub pärast testi lõppu ja viib tulemuste vaatesse.
    private Button vaataTulemusiNupp;

    // Hetkel valitud testiteema nimi.
    private String valitudTeema;

    // Hetkel valitud harjutuse tüübi nimi.
    private String valitudHarjutuseTyyp;

    // Testi ajal kasutatavad aktiivsed küsimused.
    private List<Kusimus> aktiivsedKysimused = new ArrayList<>();

    // Kasutaja vastuste kirjed, mis salvestatakse pärast testi lõppu.
    private List<TestiVastuseKirje> testiVastused = new ArrayList<>();

    // Näitab, mitmes küsimus testis hetkel käsil on.
    private int kysimuseIndeks;

    // Kasutaja õigete vastuste arv.
    private int punktid;

    // Testivaates kuvatav küsimuse tekst.
    private Label testiKysimusLabel;

    // Tekstiväli, kuhu kasutaja sisestab vastuse.
    private TextField vastuseVali;

    // Kordamiskaartide tekstid.
    private List<String> kordamisKaardid = new ArrayList<>();

    // Näitab, mitmes kordamiskaart hetkel avatud on.
    private int kaardiIndeks;

    // Kordamisvaate pealkiri.
    private Label kaardiPealkiri;

    // Kordamisvaates kuvatav kaardi sisu.
    private Label kaardiTekst;

    // Näitab kaardi järjekorranumbrit.
    private Label kaardiInfo;

    // Määrab, kas kordamiskaardi vastus on hetkel nähtav või mitte.
    private boolean vastusNahtav;

    // Nupp, millega saab kordamiskaardi vastust näidata või järgmisele kaardile liikuda.
    private Button naitaVastusNupp;

    /**
     * JavaFX rakenduse käivitusmeetod.
     * Meetod kutsub kõigepealt sisse andmete laadimise,
     * loob akna põhistruktuuri, lisab kujundusfaili,
     * määrab klaviatuuri otseteed ning kuvab akna.
     *
     * @param stage JavaFX põhiaken
     */
    @Override
    public void start(Stage stage) {
        laeAndmed();

        juur = new BorderPane();
        juur.getStyleClass().add("root-pane");

        juur.setTop(looPealkiri());
        juur.setLeft(looMenyy());
        juur.setCenter(looAvaleht());
        juur.setBottom(looAlumineRiba());

        Scene scene = new Scene(juur, 980, 640);
        scene.getStylesheets().add(
                Objects.requireNonNull(getClass().getResource("/kujundus.css")).toExternalForm()
        );

        lisaKlaviatuuriOtseteed(scene);

        stage.setTitle("Matemaatika programm");
        stage.setMinWidth(760);
        stage.setMinHeight(500);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Loeb õppematerjalid tekstifailidest sisse.
     * Sama teema kohta luuakse nii kordamismaterjalid kui ka testiküsimused.
     * Andmed salvestatakse kahte Map-struktuuri:
     * kordamiseAndmed ja testiAndmed.
     */
    private void laeAndmed() {
        kordamiseAndmed.put("Matemaatiline loogika", AndmeHoidla.looKordamiseTeemad("matemaatiline_loogika.txt"));
        kordamiseAndmed.put("Hulgateooria", AndmeHoidla.looKordamiseTeemad("hulgateooria.txt"));
        kordamiseAndmed.put("Arvuteooria", AndmeHoidla.looKordamiseTeemad("arvuteooria.txt"));
        kordamiseAndmed.put("Funktsioonid", AndmeHoidla.looKordamiseTeemad("funktsioonid.txt"));
        kordamiseAndmed.put("Hulgavõimsus", AndmeHoidla.looKordamiseTeemad("hulgavõimsus.txt"));
        kordamiseAndmed.put("Seosed", AndmeHoidla.looKordamiseTeemad("seosed.txt"));

        testiAndmed.put("Matemaatiline loogika", AndmeHoidla.looTestiTeemad("matemaatiline_loogika.txt"));
        testiAndmed.put("Hulgateooria", AndmeHoidla.looTestiTeemad("hulgateooria.txt"));
        testiAndmed.put("Arvuteooria", AndmeHoidla.looTestiTeemad("arvuteooria.txt"));
        testiAndmed.put("Funktsioonid", AndmeHoidla.looTestiTeemad("funktsioonid.txt"));
        testiAndmed.put("Hulgavõimsus", AndmeHoidla.looTestiTeemad("hulgavõimsus.txt"));
        testiAndmed.put("Seosed", AndmeHoidla.looTestiTeemad("seosed.txt"));
    }

    /**
     * Loob rakenduse ülemise pealkirjariba.
     *
     * @return valmis pealkirjariba Node-objektina
     */
    private Node looPealkiri() {
        Label pealkiri = new Label("Matemaatika programm – kordamine ja testimine");
        pealkiri.getStyleClass().add("app-title");

        HBox kast = new HBox(pealkiri);
        kast.getStyleClass().add("top-bar");

        return kast;
    }

    /**
     * Loob vasakul asuva peamenüü.
     * Menüüs on nupud avalehele, kordamisse, testi ja tulemuste vaatamiseks.
     *
     * @return valmis menüü VBox-konteinerina
     */
    private VBox looMenyy() {
        Button avaleht = looMenyyNupp("Avaleht");
        Button kordamine = looMenyyNupp("Kordamine");
        Button test = looMenyyNupp("Test");
        Button tulemused = looMenyyNupp("Tulemused failist");

        avaleht.setOnAction(e -> kuvaAvaleht());
        kordamine.setOnAction(e -> kuvaValikuVaade(true));
        test.setOnAction(e -> kuvaValikuVaade(false));
        tulemused.setOnAction(e -> kuvaTulemusteVaade());

        VBox menyy = new VBox(12, avaleht, kordamine, test, tulemused);
        menyy.getStyleClass().add("side-menu");
        menyy.setPrefWidth(210);

        return menyy;
    }

    /**
     * Loob ühe menüünupu ühtse kujundusega.
     *
     * @param tekst nupul kuvatav tekst
     * @return valmis Button-objekt
     */
    private Button looMenyyNupp(String tekst) {
        Button nupp = new Button(tekst);
        nupp.getStyleClass().add("menu-button");
        nupp.setMaxWidth(Double.MAX_VALUE);
        nupp.setMinHeight(42);

        return nupp;
    }

    /**
     * Loob alumise olekuriba.
     * Olekuribal näidatakse kasutajale teateid ja vajadusel nuppu tulemuste vaatamiseks.
     *
     * @return valmis alumine riba Node-objektina
     */
    private Node looAlumineRiba() {
        olekuTekst = new Label("");
        olekuTekst.getStyleClass().add("status-text");

        vaataTulemusiNupp = new Button("Vaata tulemusi");
        vaataTulemusiNupp.getStyleClass().add("small-primary-button");
        vaataTulemusiNupp.setVisible(false);
        vaataTulemusiNupp.setManaged(false);
        vaataTulemusiNupp.setOnAction(e -> kuvaTulemusteVaade());

        Region venitus = new Region();
        HBox.setHgrow(venitus, Priority.ALWAYS);

        alumineRiba = new HBox(12, olekuTekst, venitus, vaataTulemusiNupp);
        alumineRiba.getStyleClass().add("bottom-bar");
        alumineRiba.setAlignment(Pos.CENTER_LEFT);

        return alumineRiba;
    }

    /**
     * Kuvab rakenduse avalehe.
     * Samuti peidab tulemuste nupu ja uuendab olekuriba teksti.
     */
    private void kuvaAvaleht() {
        juur.setCenter(looAvaleht());
        peidaTulemusteNupp();
        naitaTeade("Vali vasakult kordamine, test või tulemused.");
    }

    /**
     * Loob avalehe sisu.
     * Avalehel kuvatakse sissejuhatus, kasutusjuhised ja õppimisnõuanded.
     *
     * @return avalehe paigutus Pane-objektina
     */
    private Pane looAvaleht() {
        Label sissejuhatus = new Label(
                "Tere tulemast! See programm aitab matemaatika teemasid korrata ja oma teadmisi testida."
        );
        sissejuhatus.getStyleClass().add("intro-text");
        sissejuhatus.setWrapText(true);

        VBox juhised = looInfoKaart("Kuidas kasutada?",
                "1. Vali vasakult kordamine või test.\n" +
                        "2. Vali teema ja harjutuse tüüp.\n" +
                        "3. Kasuta hiirt või klaviatuuri: Enter, tühik ja Esc on toetatud.\n" +
                        "4. Testi tulemused salvestatakse faili ning neid saab hiljem avada.");

        VBox nipid = looInfoKaart("Õppimise nõuanded",
                "• Tee esmalt kordamine ja alles siis test.\n" +
                        "• Vale vastuse korral loe õige vastus rahulikult läbi.\n" +
                        "• Väikesed kordamissessioonid aitavad paremini keskenduda.");

        HBox kaardid = new HBox(18, juhised, nipid);
        kaardid.getStyleClass().add("card-row");
        HBox.setHgrow(juhised, Priority.ALWAYS);
        HBox.setHgrow(nipid, Priority.ALWAYS);

        VBox sisu = new VBox(22, sissejuhatus, kaardid);
        sisu.getStyleClass().add("content-area");

        return new StackPane(sisu);
    }

    /**
     * Loob infokaardi, mida kasutatakse avalehel ja valikuvaates.
     *
     * @param pealkiri kaardi pealkiri
     * @param tekst kaardi põhitekst
     * @return valmis infokaart VBox-konteinerina
     */
    private VBox looInfoKaart(String pealkiri, String tekst) {
        Label p = new Label(pealkiri);
        p.getStyleClass().add("card-title");

        Label t = new Label(tekst);
        t.getStyleClass().add("card-text");
        t.setWrapText(true);

        VBox kaart = new VBox(12, p, t);
        kaart.getStyleClass().add("card");

        return kaart;
    }

    /**
     * Kuvab teema ja harjutuse tüübi valikuvaate.
     *
     * @param kordamine true, kui avatakse kordamise valik;
     *                  false, kui avatakse testi valik
     */
    private void kuvaValikuVaade(boolean kordamine) {
        juur.setCenter(looValikuVaade(kordamine));
        peidaTulemusteNupp();

        naitaTeade(kordamine
                ? "Vali kordamiseks teema ja harjutuse tüüp."
                : "Vali testimiseks teema ja harjutuse tüüp.");
    }

    /**
     * Loob teema ja harjutuse tüübi valiku vaate.
     * Sama meetodit kasutatakse nii kordamise kui ka testi alustamiseks.
     *
     * @param kordamine true, kui luuakse kordamise valik;
     *                  false, kui luuakse testi valik
     * @return valmis valikuvaade Pane-objektina
     */
    private Pane looValikuVaade(boolean kordamine) {
        ComboBox<String> teemaValik = new ComboBox<>();
        teemaValik.getItems().addAll(kordamine ? kordamiseAndmed.keySet() : testiAndmed.keySet());
        teemaValik.getSelectionModel().selectFirst();
        teemaValik.getStyleClass().add("combo-box-modern");

        ComboBox<String> harjutuseTyypValik = new ComboBox<>();
        harjutuseTyypValik.getStyleClass().add("combo-box-modern");

        uuendaHarjutuseTyyp(teemaValik, harjutuseTyypValik, kordamine);
        teemaValik.setOnAction(e -> uuendaHarjutuseTyyp(teemaValik, harjutuseTyypValik, kordamine));

        Button alusta = new Button(kordamine ? "Alusta kordamist" : "Alusta testi");
        alusta.getStyleClass().add("primary-button");
        alusta.setDefaultButton(true);

        alusta.setOnAction(e -> {
            try {
                String teema = teemaValik.getValue();
                int tyypIndeks = harjutuseTyypValik.getSelectionModel().getSelectedIndex();

                if (teema == null || tyypIndeks < 0) {
                    throw new IllegalArgumentException("Palun vali teema ja harjutuse tüüp.");
                }

                if (kordamine) {
                    alustaKordamist(teema, tyypIndeks);
                } else {
                    alustaTesti(teema, tyypIndeks);
                }
            } catch (Exception ex) {
                naitaViga(ex.getMessage());
            }
        });

        VBox valikud = new VBox(10,
                looVormireaPealkiri("Teema"), teemaValik,
                looVormireaPealkiri("Harjutuse tüüp"), harjutuseTyypValik,
                alusta);

        valikud.getStyleClass().add("card");
        valikud.setMaxWidth(430);

        VBox kirjeldus = looInfoKaart(kordamine ? "Kordamine" : "Test",
                kordamine
                        ? "Kordamises saad kaarte vaadata. Tühik või Enter näitab vastust ja liigub järgmisele kaardile."
                        : "Testis kirjutad vastuse tekstiväljale. Enter kinnitab vastuse ning lõpus salvestatakse tulemus faili.");

        kirjeldus.setMaxWidth(430);

        HBox sisu = new HBox(22, valikud, kirjeldus);
        sisu.getStyleClass().add("content-area");
        sisu.setAlignment(Pos.CENTER);

        return new StackPane(sisu);
    }

    /**
     * Loob vormirea pealkirja.
     * Kasutatakse näiteks tekstide "Teema:" ja "Harjutuse tüüp:" kuvamiseks.
     *
     * @param tekst pealkirja tekst
     * @return valmis Label-objekt
     */
    private Label looVormireaPealkiri(String tekst) {
        Label label = new Label(tekst + ":");
        label.getStyleClass().add("form-label");

        return label;
    }

    /**
     * Uuendab harjutuse tüübi valikut vastavalt valitud teemale.
     * Kui kasutaja valib uue teema, täidetakse teine ComboBox selle teema tüüpidega.
     *
     * @param teemaValik teema valiku ComboBox
     * @param harjutuseTyypValik harjutuse tüübi valiku ComboBox
     * @param kordamine true, kui kasutatakse kordamise andmeid;
     *                  false, kui kasutatakse testi andmeid
     */
    private void uuendaHarjutuseTyyp(ComboBox<String> teemaValik,
                                     ComboBox<String> harjutuseTyypValik,
                                     boolean kordamine) {
        harjutuseTyypValik.getItems().clear();

        String teema = teemaValik.getValue();
        if (teema == null) return;

        if (kordamine) {
            for (KordamisTeema t : kordamiseAndmed.get(teema)) {
                harjutuseTyypValik.getItems().add(vormindaTyyp(t.getNimi()));
            }
        } else {
            for (TestiTeema t : testiAndmed.get(teema)) {
                harjutuseTyypValik.getItems().add(vormindaTyyp(t.getNimi()));
            }
        }

        harjutuseTyypValik.getSelectionModel().selectFirst();
    }

    /**
     * Vormindab harjutuse tüübi nime kasutajasõbralikumaks.
     * Näiteks muudab alakriipsud tühikuteks ja teeb esimese tähe suureks.
     *
     * @param tekst algne tüübi nimi
     * @return vormindatud tüübi nimi
     */
    private String vormindaTyyp(String tekst) {
        if (tekst == null || tekst.isBlank()) return "Määramata";

        String v = tekst.toLowerCase(Locale.ROOT).replace('_', ' ');

        return v.substring(0, 1).toUpperCase(Locale.ROOT) + v.substring(1);
    }

    /**
     * Alustab kordamisrežiimi.
     * Valitud teema kokkuvõte jagatakse kaartideks, kaardid segatakse juhuslikult
     * ning kasutajale kuvatakse esimene kordamiskaart.
     *
     * @param teemaNimi valitud teema nimi
     * @param tyypIndeks valitud harjutuse tüübi indeks
     */
    private void alustaKordamist(String teemaNimi, int tyypIndeks) {
        KordamisTeema teema = kordamiseAndmed.get(teemaNimi).get(tyypIndeks);

        kordamisKaardid = new ArrayList<>(Arrays.asList(teema.getKokkuvote().split("\\n\\n")));
        Collections.shuffle(kordamisKaardid);

        kaardiIndeks = 0;
        vastusNahtav = false;

        kaardiPealkiri = new Label(teemaNimi + " – " + vormindaTyyp(teema.getNimi()));
        kaardiPealkiri.getStyleClass().add("section-title");

        kaardiTekst = new Label();
        kaardiTekst.setWrapText(true);
        kaardiTekst.getStyleClass().add("question-text");

        kaardiInfo = new Label();
        kaardiInfo.getStyleClass().add("muted-text");

        naitaVastusNupp = new Button("Näita vastust / järgmine");
        naitaVastusNupp.getStyleClass().add("primary-button");
        naitaVastusNupp.setOnAction(e -> liiguKordamises());

        Button tagasi = new Button("Tagasi valikusse");
        tagasi.getStyleClass().add("secondary-button");
        tagasi.setOnAction(e -> kuvaValikuVaade(true));

        HBox nupud = new HBox(12, naitaVastusNupp, tagasi);

        VBox kaart = new VBox(16, kaardiPealkiri, kaardiInfo, kaardiTekst, nupud);
        kaart.getStyleClass().add("card-large");
        VBox.setVgrow(kaardiTekst, Priority.ALWAYS);

        StackPane sisu = new StackPane(kaart);
        sisu.getStyleClass().add("content-area");

        juur.setCenter(sisu);

        uuendaKordamisKaart();

        Platform.runLater(() -> naitaVastusNupp.requestFocus());
    }

    /**
     * Liigub kordamisrežiimis edasi.
     * Kui vastus ei ole nähtav, siis näidatakse vastust.
     * Kui vastus on juba nähtav, liigutakse järgmisele kaardile.
     * Viimase kaardi järel kuvatakse teade, et kordamine sai läbi.
     */
    private void liiguKordamises() {
        if (kaardiTekst == null || kordamisKaardid.isEmpty()) return;

        if (!vastusNahtav) {
            vastusNahtav = true;
        } else if (kaardiIndeks < kordamisKaardid.size() - 1) {
            kaardiIndeks++;
            vastusNahtav = false;
        } else {
            naitaTeade("Kordamine sai läbi.");
            return;
        }

        uuendaKordamisKaart();

        Platform.runLater(() -> naitaVastusNupp.requestFocus());
    }

    /**
     * Uuendab kordamiskaardi sisu.
     * Meetod eraldab kaardi tekstist küsimuse ja vastuse.
     * Kui vastusNahtav on false, kuvatakse ainult küsimus.
     * Kui vastusNahtav on true, kuvatakse ka vastus.
     */
    private void uuendaKordamisKaart() {
        String[] osad = kordamisKaardid.get(kaardiIndeks).split("\n", 2);

        String kysimus = osad[0];
        String vastus = osad.length > 1 ? osad[1] : "Vastus puudub.";

        kaardiInfo.setText("Kaart " + (kaardiIndeks + 1) + " / " + kordamisKaardid.size());
        kaardiTekst.setText(vastusNahtav ? kysimus + "\n\nVastus:\n" + vastus : kysimus);
    }

    /**
     * Alustab testirežiimi.
     * Valitud teema küsimused segatakse juhuslikult,
     * punktid ja indeksid nullitakse ning kasutajale kuvatakse esimene küsimus.
     *
     * @param teemaNimi valitud teema nimi
     * @param tyypIndeks valitud harjutuse tüübi indeks
     */
    private void alustaTesti(String teemaNimi, int tyypIndeks) {
        valitudTeema = teemaNimi;

        TestiTeema teema = testiAndmed.get(teemaNimi).get(tyypIndeks);
        valitudHarjutuseTyyp = vormindaTyyp(teema.getNimi());

        aktiivsedKysimused = new ArrayList<>(teema.getKysimused());
        testiVastused = new ArrayList<>();

        Collections.shuffle(aktiivsedKysimused);

        kysimuseIndeks = 0;
        punktid = 0;

        Label pealkiri = new Label(teemaNimi + " – " + valitudHarjutuseTyyp);
        pealkiri.getStyleClass().add("section-title");

        testiKysimusLabel = new Label();
        testiKysimusLabel.setWrapText(true);
        testiKysimusLabel.getStyleClass().add("question-text");

        vastuseVali = new TextField();
        vastuseVali.setPromptText("Kirjuta vastus siia ja vajuta Enter");
        vastuseVali.getStyleClass().add("answer-field");
        vastuseVali.setOnAction(e -> kontrolliVastus(teema));

        Button vasta = new Button("Vasta");
        vasta.getStyleClass().add("primary-button");
        vasta.setDefaultButton(true);
        vasta.setOnAction(e -> kontrolliVastus(teema));

        VBox kaart = new VBox(16, pealkiri, testiKysimusLabel, vastuseVali, vasta);
        kaart.getStyleClass().add("card-large");
        VBox.setVgrow(testiKysimusLabel, Priority.ALWAYS);

        StackPane sisu = new StackPane(kaart);
        sisu.getStyleClass().add("content-area");

        juur.setCenter(sisu);

        uuendaTestiKysimus();

        Platform.runLater(() -> vastuseVali.requestFocus());
    }

    /**
     * Kontrollib kasutaja sisestatud vastust.
     * Kui vastus on tühi, kuvatakse veateade.
     * Kui vastus on korrektne, suurendatakse punktisummat.
     * Iga vastus salvestatakse testiVastused listi,
     * et hiljem oleks võimalik kuvada testi detailid.
     *
     * @param teema aktiivne testiteema
     */
    private void kontrolliVastus(TestiTeema teema) {
        try {
            String vastus = vastuseVali.getText();

            if (vastus == null || vastus.isBlank()) {
                throw new IllegalArgumentException("Vastus ei tohi olla tühi.");
            }

            Kusimus kysimus = aktiivsedKysimused.get(kysimuseIndeks);
            boolean oige = kysimus.kontrolliVastus(vastus);

            testiVastused.add(new TestiVastuseKirje(
                    kysimus.getTekst(),
                    vastus.trim(),
                    kysimus.getOigeVastus(),
                    oige
            ));

            if (oige) {
                punktid++;
                naitaTeade("Õige vastus!");
            } else {
                naitaViga("Vale. Õige vastus: " + kysimus.getOigeVastus());
            }

            kysimuseIndeks++;
            vastuseVali.clear();

            if (kysimuseIndeks >= aktiivsedKysimused.size()) {
                lõpetaTest(teema);
            } else {
                uuendaTestiKysimus();
                Platform.runLater(() -> vastuseVali.requestFocus());
            }

        } catch (IllegalArgumentException ex) {
            naitaViga(ex.getMessage());
        } catch (Exception ex) {
            naitaViga("Vastuse kontrollimisel tekkis viga: " + ex.getMessage());
        }
    }

    /**
     * Kuvab järgmise testiküsimuse.
     * Meetod võtab aktiivsete küsimuste listist praeguse küsimuse
     * ning uuendab küsimuse tekstisildi sisu.
     */
    private void uuendaTestiKysimus() {
        Kusimus kysimus = aktiivsedKysimused.get(kysimuseIndeks);

        testiKysimusLabel.setText(
                "Küsimus " + (kysimuseIndeks + 1) + " / " + aktiivsedKysimused.size()
                        + "\n\n" + kysimus.getTekst()
        );
    }

    /**
     * Lõpetab testi.
     * Meetod proovib tulemuse faili salvestada,
     * kuvab kasutajale kokkuvõtte ning annab võimaluse teha uus test
     * või vaadata varasemaid tulemusi.
     *
     * @param teema testiteema, mille test lõpetati
     */
    private void lõpetaTest(TestiTeema teema) {
        try {
            tulemusteHaldur.salvestaTulemus(
                    valitudTeema,
                    valitudHarjutuseTyyp,
                    punktid,
                    aktiivsedKysimused.size(),
                    testiVastused
            );

            naitaTeade("Test lõpetatud! Tulemus salvestati faili.");
            naitaTulemusteNupp();

        } catch (IOException ex) {
            naitaViga("Tulemust ei õnnestunud faili salvestada: " + ex.getMessage());
        }

        Label tulemus = new Label(
                "Test läbi!\n\nSinu tulemus: " + punktid + " / " + aktiivsedKysimused.size()
        );
        tulemus.getStyleClass().add("result-title");

        Button uusTest = new Button("Tee uus test");
        uusTest.getStyleClass().add("secondary-button");
        uusTest.setOnAction(e -> kuvaValikuVaade(false));

        Button tulemused = new Button("Vaata tulemusi");
        tulemused.getStyleClass().add("primary-button");
        tulemused.setOnAction(e -> kuvaTulemusteVaade());

        VBox kaart = new VBox(20, tulemus, new HBox(12, uusTest, tulemused));
        kaart.getStyleClass().add("card-large");

        juur.setCenter(new StackPane(kaart));
    }

    /**
     * Kuvab tulemuste vaate.
     * Peidab alumise tulemuste nupu ning annab kasutajale juhise,
     * kuidas detailseid tulemusi avada.
     */
    private void kuvaTulemusteVaade() {
        juur.setCenter(looTulemusteVaade());
        peidaTulemusteNupp();
        naitaTeade("Klõpsa tulemusel kaks korda, et näha kogu läbitud testi.");
    }

    /**
     * Loob tulemuste vaate.
     * Meetod loeb tulemused failist ja kuvab need ListView-komponendis.
     * Kasutaja saab tulemuse avada topeltklõpsuga või eraldi nupuga.
     *
     * @return valmis tulemuste vaade Pane-objektina
     */
    private Pane looTulemusteVaade() {
        ListView<TulemuseKirje> list = new ListView<>();
        list.getStyleClass().add("result-list");

        try {
            List<TulemuseKirje> tulemused = tulemusteHaldur.loeTulemused();

            if (tulemused.isEmpty()) {
                naitaTeade("Tulemusi ei ole veel salvestatud.");
            } else {
                list.getItems().addAll(tulemused);
            }

        } catch (Exception ex) {
            naitaViga("Tulemuste lugemisel tekkis viga: " + ex.getMessage());
        }

        list.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && list.getSelectionModel().getSelectedItem() != null) {
                avaTulemuseDetailid(list.getSelectionModel().getSelectedItem());
            }
        });

        Button ava = new Button("Ava valitud tulemus");
        ava.getStyleClass().add("primary-button");

        ava.setOnAction(e -> {
            TulemuseKirje valitud = list.getSelectionModel().getSelectedItem();

            if (valitud == null) {
                naitaViga("Vali esmalt nimekirjast tulemus.");
            } else {
                avaTulemuseDetailid(valitud);
            }
        });

        VBox kaart = new VBox(14, new Label("Varasemad tulemused"), list, ava);
        kaart.getStyleClass().add("card-large");
        VBox.setVgrow(list, Priority.ALWAYS);

        StackPane sisu = new StackPane(kaart);
        sisu.getStyleClass().add("content-area");

        return sisu;
    }

    /**
     * Avab ühe testitulemuse detailid uues modaalses aknas.
     * Detailivaates kuvatakse testi teema, aeg, punktid ja iga küsimuse vastus.
     *
     * @param kirje valitud tulemuse kirje
     */
    private void avaTulemuseDetailid(TulemuseKirje kirje) {
        Stage aken = new Stage();
        aken.initModality(Modality.APPLICATION_MODAL);
        aken.setTitle("Läbitud testi detailid");

        Label pealkiri = new Label(kirje.getTeema() + " – " + kirje.getHarjutuseTyyp());
        pealkiri.getStyleClass().add("section-title");

        Label info = new Label(
                kirje.getAeg() + "   |   Tulemus: " + kirje.getPunktid() + " / " + kirje.getKokku()
        );
        info.getStyleClass().add("muted-text");

        VBox vastusteKast = new VBox(12);
        List<TestiVastuseKirje> vastused = kirje.getVastused();

        if (vastused.isEmpty()) {
            Label puudub = new Label(
                    "Selle tulemuse kohta ei ole detailseid küsimusi salvestatud. " +
                            "Vanad tulemused sisaldavad ainult kokkuvõtet."
            );
            puudub.setWrapText(true);
            puudub.getStyleClass().add("card-text");
            vastusteKast.getChildren().add(puudub);
        } else {
            for (int i = 0; i < vastused.size(); i++) {
                vastusteKast.getChildren().add(looVastuseKaart(i + 1, vastused.get(i)));
            }
        }

        ScrollPane scroll = new ScrollPane(vastusteKast);
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("transparent-scroll");

        Button sulge = new Button("Sulge");
        sulge.getStyleClass().add("secondary-button");
        sulge.setOnAction(e -> aken.close());

        VBox sisu = new VBox(16, pealkiri, info, scroll, sulge);
        sisu.getStyleClass().add("content-area");
        sisu.setPadding(new Insets(18));

        Scene scene = new Scene(sisu, 720, 560);
        scene.getStylesheets().add(
                Objects.requireNonNull(getClass().getResource("/kujundus.css")).toExternalForm()
        );

        aken.setScene(scene);
        aken.showAndWait();
    }

    /**
     * Loob ühe vastusekaardi tulemuste detailivaates.
     * Kaardil kuvatakse, kas vastus oli õige või vale,
     * küsimuse tekst, kasutaja vastus ja õige vastus.
     *
     * @param nr küsimuse järjekorranumber
     * @param vastus ühe küsimuse vastuse kirje
     * @return valmis vastusekaart VBox-konteinerina
     */
    private VBox looVastuseKaart(int nr, TestiVastuseKirje vastus) {
        Label tulemus = new Label(vastus.isOige() ? "Õige" : "Vale");
        tulemus.getStyleClass().add(vastus.isOige() ? "correct-pill" : "wrong-pill");

        Label kysimus = new Label(nr + ". " + vastus.getKysimus());
        kysimus.setWrapText(true);
        kysimus.getStyleClass().add("card-text");

        Label kasutajaVastus = new Label("Sinu vastus: " + vastus.getKasutajaVastus());
        kasutajaVastus.setWrapText(true);
        kasutajaVastus.getStyleClass().add("muted-text");

        Label oigeVastus = new Label("Õige vastus: " + vastus.getOigeVastus());
        oigeVastus.setWrapText(true);
        oigeVastus.getStyleClass().add("muted-text");

        HBox ylarida = new HBox(10, tulemus, kysimus);
        ylarida.setAlignment(Pos.CENTER_LEFT);

        VBox kaart = new VBox(8, ylarida, kasutajaVastus, oigeVastus);
        kaart.getStyleClass().add("answer-card");

        return kaart;
    }

    /**
     * Lisab rakendusele klaviatuuri otseteed.
     * Escape viib kasutaja avalehele.
     * Tühik ja Enter juhivad kordamiskaarte, kui kordamisvaade on aktiivne.
     *
     * @param scene stseen, millele klaviatuuri sündmused lisatakse
     */
    private void lisaKlaviatuuriOtseteed(Scene scene) {
        scene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                kuvaAvaleht();
                event.consume();

            } else if ((event.getCode() == KeyCode.SPACE || event.getCode() == KeyCode.ENTER)
                    && naitaVastusNupp != null
                    && naitaVastusNupp.getScene() != null) {

                liiguKordamises();
                event.consume();
            }
        });
    }

    /**
     * Näitab alumisel ribal tulemuste nuppu.
     * Seda kasutatakse näiteks pärast testi lõpetamist.
     */
    private void naitaTulemusteNupp() {
        vaataTulemusiNupp.setVisible(true);
        vaataTulemusiNupp.setManaged(true);
    }

    /**
     * Peidab alumisel ribal oleva tulemuste nupu.
     * setManaged(false) tähendab, et peidetud nupp ei võta paigutuses ruumi.
     */
    private void peidaTulemusteNupp() {
        vaataTulemusiNupp.setVisible(false);
        vaataTulemusiNupp.setManaged(false);
    }

    /**
     * Kuvab alumisel ribal tavalise olekuteate.
     * Meetod eemaldab veateate stiili, kui see oli varem lisatud.
     *
     * @param tekst kasutajale kuvatav teade
     */
    private void naitaTeade(String tekst) {
        olekuTekst.setText(tekst);
        olekuTekst.getStyleClass().removeAll("status-error");

        if (!olekuTekst.getStyleClass().contains("status-text")) {
            olekuTekst.getStyleClass().add("status-text");
        }
    }

    /**
     * Kuvab alumisel ribal veateate.
     * Veateatele lisatakse eraldi CSS-klass, et see oleks kasutajale paremini märgatav.
     *
     * @param tekst veateate sisu
     */
    private void naitaViga(String tekst) {
        olekuTekst.setText("Viga: " + tekst);

        if (!olekuTekst.getStyleClass().contains("status-error")) {
            olekuTekst.getStyleClass().add("status-error");
        }
    }
}