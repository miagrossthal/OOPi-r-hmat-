package com.example.oop_graafika;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/** Ühe lõpetatud testi tulemus koos soovi korral detailsete vastustega. */
public class TulemuseKirje {
    private final String aeg;
    private final String teema;
    private final String harjutuseTyyp;
    private final int punktid;
    private final int kokku;
    private final List<TestiVastuseKirje> vastused;

    public TulemuseKirje(String aeg, String teema, String harjutuseTyyp, int punktid, int kokku) {
        this(aeg, teema, harjutuseTyyp, punktid, kokku, new ArrayList<>());
    }

    public TulemuseKirje(String aeg, String teema, String harjutuseTyyp, int punktid, int kokku,
                         List<TestiVastuseKirje> vastused) {
        this.aeg = aeg;
        this.teema = teema;
        this.harjutuseTyyp = harjutuseTyyp;
        this.punktid = punktid;
        this.kokku = kokku;
        this.vastused = vastused == null ? new ArrayList<>() : new ArrayList<>(vastused);
    }

    public String getAeg() { return aeg; }
    public String getTeema() { return teema; }
    public String getHarjutuseTyyp() { return harjutuseTyyp; }
    public int getPunktid() { return punktid; }
    public int getKokku() { return kokku; }
    public List<TestiVastuseKirje> getVastused() { return new ArrayList<>(vastused); }

    /** Vormindab tulemuse faili jaoks. Detailid kodeeritakse Base64 kujule, et semikoolonid ja reavahetused faili ei lõhuks. */
    public String vormindaFailiReaks() {
        return kodeeri(aeg) + ";" + kodeeri(teema) + ";" + kodeeri(harjutuseTyyp) + ";" + punktid + ";" + kokku + ";" + kodeeriDetailid();
    }

    public static TulemuseKirje loeFailiReast(String rida) {
        String[] osad = rida.split(";", -1);

        // Vanade tulemusefailide tugi: aeg;aine;teema;punktid;kokku
        if (osad.length == 5) {
            return new TulemuseKirje(osad[0], osad[1], osad[2], Integer.parseInt(osad[3]), Integer.parseInt(osad[4]));
        }

        if (osad.length != 6) throw new IllegalArgumentException("Vale tulemuse rida: " + rida);
        return new TulemuseKirje(
                dekodeeri(osad[0]),
                dekodeeri(osad[1]),
                dekodeeri(osad[2]),
                Integer.parseInt(osad[3]),
                Integer.parseInt(osad[4]),
                dekodeeriDetailid(osad[5])
        );
    }

    private String kodeeriDetailid() {
        StringBuilder sb = new StringBuilder();
        for (TestiVastuseKirje v : vastused) {
            sb.append(kodeeri(v.getKysimus())).append("|")
                    .append(kodeeri(v.getKasutajaVastus())).append("|")
                    .append(kodeeri(v.getOigeVastus())).append("|")
                    .append(v.isOige()).append("\n");
        }
        return kodeeri(sb.toString());
    }

    private static List<TestiVastuseKirje> dekodeeriDetailid(String tekst) {
        List<TestiVastuseKirje> vastused = new ArrayList<>();
        String detailid = dekodeeri(tekst);
        if (detailid.isBlank()) return vastused;

        for (String rida : detailid.split("\\n")) {
            if (rida.isBlank()) continue;
            String[] osad = rida.split("\\|", -1);
            if (osad.length == 4) {
                vastused.add(new TestiVastuseKirje(
                        dekodeeri(osad[0]),
                        dekodeeri(osad[1]),
                        dekodeeri(osad[2]),
                        Boolean.parseBoolean(osad[3])
                ));
            }
        }
        return vastused;
    }

    private static String kodeeri(String tekst) {
        if (tekst == null) tekst = "";
        return Base64.getEncoder().encodeToString(tekst.getBytes(StandardCharsets.UTF_8));
    }

    private static String dekodeeri(String tekst) {
        if (tekst == null || tekst.isEmpty()) return "";
        return new String(Base64.getDecoder().decode(tekst), StandardCharsets.UTF_8);
    }

    @Override
    public String toString() {
        return aeg + " | " + teema + " | " + harjutuseTyyp + " | " + punktid + "/" + kokku;
    }
}
