package com.example.oop_graafika;

/**************************************************************************
 * Objektorienteeritud programmeerimine LTAT.03.003 2025/2026 kevadsemester
 * Rühmatöö nr 2
 * Teema: Matemaatika programm JavaFX graafilise kasutajaliidesega
 * Autorid: Mia Grossthal, Joosep-Gre Kallaste
 **************************************************************************/

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;

/**
 * JavaFX rakenduse põhiklass.
 * Siin on vaated, nupud, klaviatuuri sündmused ja tulemuste kuvamine.
 */
public class GraafilineRakendus extends Application {
    private final Map<String, List<KordamisTeema>> kordamiseAndmed = new LinkedHashMap<>();
    private final Map<String, List<TestiTeema>> testiAndmed = new LinkedHashMap<>();
    private final TulemusteHaldur tulemusteHaldur = new TulemusteHaldur();

    private BorderPane juur;
    private HBox alumineRiba;
    private Label olekuTekst;
    private Button vaataTulemusiNupp;

    private String valitudTeema;
    private String valitudHarjutuseTyyp;
    private List<Kusimus> aktiivsedKysimused = new ArrayList<>();
    private List<TestiVastuseKirje> testiVastused = new ArrayList<>();
    private int kysimuseIndeks;
    private int punktid;
    private Label testiKysimusLabel;
    private TextField vastuseVali;

    private List<String> kordamisKaardid = new ArrayList<>();
    private int kaardiIndeks;
    private Label kaardiPealkiri;
    private Label kaardiTekst;
    private Label kaardiInfo;
    private boolean vastusNahtav;
    private Button naitaVastusNupp;

    @Override
    public void start(Stage stage) {
        laeAndmed();

        juur = new BorderPane();
        juur.getStyleClass().add("root-pane");
        juur.setTop(looPealkiri());
        juur.setLeft(looMenyy());
        juur.setCenter(looAvaleht());
        juur.setBottom(looAlumineRiba());

        Scene scene = new Scene(juur, 980, 640);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/kujundus.css")).toExternalForm());
        lisaKlaviatuuriOtseteed(scene);

        stage.setTitle("Matemaatika programm");
        stage.setMinWidth(760);
        stage.setMinHeight(500);
        stage.setScene(scene);
        stage.show();
    }

    /** Loeb õppematerjalid txt-failidest sisse. */
    private void laeAndmed() {
        kordamiseAndmed.put("Matemaatiline loogika", AndmeHoidla.looKordamiseTeemad("matemaatiline_loogika.txt"));
        kordamiseAndmed.put("Hulgateooria", AndmeHoidla.looKordamiseTeemad("hulgateooria.txt"));
        kordamiseAndmed.put("Arvuteooria", AndmeHoidla.looKordamiseTeemad("arvuteooria.txt"));
        kordamiseAndmed.put("Funktsioonid", AndmeHoidla.looKordamiseTeemad("funktsioonid.txt"));
        kordamiseAndmed.put("Hulgavõimsus", AndmeHoidla.looKordamiseTeemad("hulgavõimsus.txt"));
        kordamiseAndmed.put("Seosed", AndmeHoidla.looKordamiseTeemad("seosed.txt"));

        testiAndmed.put("Matemaatiline loogika", AndmeHoidla.looTestiTeemad("matemaatiline_loogika.txt"));
        testiAndmed.put("Hulgateooria", AndmeHoidla.looTestiTeemad("hulgateooria.txt"));
        testiAndmed.put("Arvuteooria", AndmeHoidla.looTestiTeemad("arvuteooria.txt"));
        testiAndmed.put("Funktsioonid", AndmeHoidla.looTestiTeemad("funktsioonid.txt"));
        testiAndmed.put("Hulgavõimsus", AndmeHoidla.looTestiTeemad("hulgavõimsus.txt"));
        testiAndmed.put("Seosed", AndmeHoidla.looTestiTeemad("seosed.txt"));

    }

    private Node looPealkiri() {
        Label pealkiri = new Label("Matemaatika programm – kordamine ja testimine");
        pealkiri.getStyleClass().add("app-title");
        HBox kast = new HBox(pealkiri);
        kast.getStyleClass().add("top-bar");
        return kast;
    }

    /** Vasak menüü kasutab hiireklikke. */
    private VBox looMenyy() {
        Button avaleht = looMenyyNupp("Avaleht");
        Button kordamine = looMenyyNupp("Kordamine");
        Button test = looMenyyNupp("Test");
        Button tulemused = looMenyyNupp("Tulemused failist");

        avaleht.setOnAction(e -> kuvaAvaleht());
        kordamine.setOnAction(e -> kuvaValikuVaade(true));
        test.setOnAction(e -> kuvaValikuVaade(false));
        tulemused.setOnAction(e -> kuvaTulemusteVaade());

        VBox menyy = new VBox(12, avaleht, kordamine, test, tulemused);
        menyy.getStyleClass().add("side-menu");
        menyy.setPrefWidth(210);
        return menyy;
    }

    private Button looMenyyNupp(String tekst) {
        Button nupp = new Button(tekst);
        nupp.getStyleClass().add("menu-button");
        nupp.setMaxWidth(Double.MAX_VALUE);
        nupp.setMinHeight(42);
        return nupp;
    }

    private Node looAlumineRiba() {
        olekuTekst = new Label("");
        olekuTekst.getStyleClass().add("status-text");

        vaataTulemusiNupp = new Button("Vaata tulemusi");
        vaataTulemusiNupp.getStyleClass().add("small-primary-button");
        vaataTulemusiNupp.setVisible(false);
        vaataTulemusiNupp.setManaged(false);
        vaataTulemusiNupp.setOnAction(e -> kuvaTulemusteVaade());

        Region venitus = new Region();
        HBox.setHgrow(venitus, Priority.ALWAYS);

        alumineRiba = new HBox(12, olekuTekst, venitus, vaataTulemusiNupp);
        alumineRiba.getStyleClass().add("bottom-bar");
        alumineRiba.setAlignment(Pos.CENTER_LEFT);
        return alumineRiba;
    }

    private void kuvaAvaleht() {
        juur.setCenter(looAvaleht());
        peidaTulemusteNupp();
        naitaTeade("Vali vasakult kordamine, test või tulemused.");
    }

    private Pane looAvaleht() {
        Label sissejuhatus = new Label("Tere tulemast! See programm aitab matemaatika teemasid korrata ja oma teadmisi testida.");
        sissejuhatus.getStyleClass().add("intro-text");
        sissejuhatus.setWrapText(true);

        VBox juhised = looInfoKaart("Kuidas kasutada?",
                "1. Vali vasakult kordamine või test.\n" +
                        "2. Vali teema ja harjutuse tüüp.\n" +
                        "3. Kasuta hiirt või klaviatuuri: Enter, tühik ja Esc on toetatud.\n" +
                        "4. Testi tulemused salvestatakse faili ning neid saab hiljem avada.");

        VBox nipid = looInfoKaart("Õppimise nõuanded",
                "• Tee esmalt kordamine ja alles siis test.\n" +
                        "• Vale vastuse korral loe õige vastus rahulikult läbi.\n" +
                        "• Väikesed kordamissessioonid aitavad paremini keskenduda.");

        HBox kaardid = new HBox(18, juhised, nipid);
        kaardid.getStyleClass().add("card-row");
        HBox.setHgrow(juhised, Priority.ALWAYS);
        HBox.setHgrow(nipid, Priority.ALWAYS);

        VBox sisu = new VBox(22, sissejuhatus, kaardid);
        sisu.getStyleClass().add("content-area");
        return new StackPane(sisu);
    }

    private VBox looInfoKaart(String pealkiri, String tekst) {
        Label p = new Label(pealkiri);
        p.getStyleClass().add("card-title");
        Label t = new Label(tekst);
        t.getStyleClass().add("card-text");
        t.setWrapText(true);
        VBox kaart = new VBox(12, p, t);
        kaart.getStyleClass().add("card");
        return kaart;
    }

    private void kuvaValikuVaade(boolean kordamine) {
        juur.setCenter(looValikuVaade(kordamine));
        peidaTulemusteNupp();
        naitaTeade(kordamine ? "Vali kordamiseks teema ja harjutuse tüüp." : "Vali testimiseks teema ja harjutuse tüüp.");
    }

    /** Loob teema ja harjutuse tüübi valiku vaate nii kordamisele kui testile. */
    private Pane looValikuVaade(boolean kordamine) {
        ComboBox<String> teemaValik = new ComboBox<>();
        teemaValik.getItems().addAll(kordamine ? kordamiseAndmed.keySet() : testiAndmed.keySet());
        teemaValik.getSelectionModel().selectFirst();
        teemaValik.getStyleClass().add("combo-box-modern");

        ComboBox<String> harjutuseTyypValik = new ComboBox<>();
        harjutuseTyypValik.getStyleClass().add("combo-box-modern");
        uuendaHarjutuseTyyp(teemaValik, harjutuseTyypValik, kordamine);
        teemaValik.setOnAction(e -> uuendaHarjutuseTyyp(teemaValik, harjutuseTyypValik, kordamine));

        Button alusta = new Button(kordamine ? "Alusta kordamist" : "Alusta testi");
        alusta.getStyleClass().add("primary-button");
        alusta.setDefaultButton(true);
        alusta.setOnAction(e -> {
            try {
                String teema = teemaValik.getValue();
                int tyypIndeks = harjutuseTyypValik.getSelectionModel().getSelectedIndex();
                if (teema == null || tyypIndeks < 0) {
                    throw new IllegalArgumentException("Palun vali teema ja harjutuse tüüp.");
                }
                if (kordamine) alustaKordamist(teema, tyypIndeks);
                else alustaTesti(teema, tyypIndeks);
            } catch (Exception ex) {
                naitaViga(ex.getMessage());
            }
        });

        VBox valikud = new VBox(10,
                looVormireaPealkiri("Teema"), teemaValik,
                looVormireaPealkiri("Harjutuse tüüp"), harjutuseTyypValik,
                alusta);
        valikud.getStyleClass().add("card");
        valikud.setMaxWidth(430);

        VBox kirjeldus = looInfoKaart(kordamine ? "Kordamine" : "Test",
                kordamine
                        ? "Kordamises saad kaarte vaadata. Tühik või Enter näitab vastust ja liigub järgmisele kaardile."
                        : "Testis kirjutad vastuse tekstiväljale. Enter kinnitab vastuse ning lõpus salvestatakse tulemus faili.");
        kirjeldus.setMaxWidth(430);

        HBox sisu = new HBox(22, valikud, kirjeldus);
        sisu.getStyleClass().add("content-area");
        sisu.setAlignment(Pos.CENTER);
        return new StackPane(sisu);
    }

    private Label looVormireaPealkiri(String tekst) {
        Label label = new Label(tekst + ":");
        label.getStyleClass().add("form-label");
        return label;
    }

    private void uuendaHarjutuseTyyp(ComboBox<String> teemaValik, ComboBox<String> harjutuseTyypValik, boolean kordamine) {
        harjutuseTyypValik.getItems().clear();
        String teema = teemaValik.getValue();
        if (teema == null) return;

        if (kordamine) {
            for (KordamisTeema t : kordamiseAndmed.get(teema)) harjutuseTyypValik.getItems().add(vormindaTyyp(t.getNimi()));
        } else {
            for (TestiTeema t : testiAndmed.get(teema)) harjutuseTyypValik.getItems().add(vormindaTyyp(t.getNimi()));
        }
        harjutuseTyypValik.getSelectionModel().selectFirst();
    }

    private String vormindaTyyp(String tekst) {
        if (tekst == null || tekst.isBlank()) return "Määramata";
        String v = tekst.toLowerCase(Locale.ROOT).replace('_', ' ');
        return v.substring(0, 1).toUpperCase(Locale.ROOT) + v.substring(1);
    }

    private void alustaKordamist(String teemaNimi, int tyypIndeks) {
        KordamisTeema teema = kordamiseAndmed.get(teemaNimi).get(tyypIndeks);
        kordamisKaardid = new ArrayList<>(Arrays.asList(teema.getKokkuvote().split("\\n\\n")));
        Collections.shuffle(kordamisKaardid);
        kaardiIndeks = 0;
        vastusNahtav = false;

        kaardiPealkiri = new Label(teemaNimi + " – " + vormindaTyyp(teema.getNimi()));
        kaardiPealkiri.getStyleClass().add("section-title");
        kaardiTekst = new Label();
        kaardiTekst.setWrapText(true);
        kaardiTekst.getStyleClass().add("question-text");
        kaardiInfo = new Label();
        kaardiInfo.getStyleClass().add("muted-text");

        naitaVastusNupp = new Button("Näita vastust / järgmine");
        naitaVastusNupp.getStyleClass().add("primary-button");
        naitaVastusNupp.setOnAction(e -> liiguKordamises());

        Button tagasi = new Button("Tagasi valikusse");
        tagasi.getStyleClass().add("secondary-button");
        tagasi.setOnAction(e -> kuvaValikuVaade(true));

        HBox nupud = new HBox(12, naitaVastusNupp, tagasi);
        VBox kaart = new VBox(16, kaardiPealkiri, kaardiInfo, kaardiTekst, nupud);
        kaart.getStyleClass().add("card-large");
        VBox.setVgrow(kaardiTekst, Priority.ALWAYS);

        StackPane sisu = new StackPane(kaart);
        sisu.getStyleClass().add("content-area");
        juur.setCenter(sisu);
        uuendaKordamisKaart();
        Platform.runLater(() -> naitaVastusNupp.requestFocus());
    }

    private void liiguKordamises() {
        if (kaardiTekst == null || kordamisKaardid.isEmpty()) return;

        if (!vastusNahtav) {
            vastusNahtav = true;
        } else if (kaardiIndeks < kordamisKaardid.size() - 1) {
            kaardiIndeks++;
            vastusNahtav = false;
        } else {
            naitaTeade("Kordamine sai läbi.");
            return;
        }
        uuendaKordamisKaart();
        Platform.runLater(() -> naitaVastusNupp.requestFocus());
    }

    private void uuendaKordamisKaart() {
        String[] osad = kordamisKaardid.get(kaardiIndeks).split("\n", 2);
        String kysimus = osad[0];
        String vastus = osad.length > 1 ? osad[1] : "Vastus puudub.";
        kaardiInfo.setText("Kaart " + (kaardiIndeks + 1) + " / " + kordamisKaardid.size());
        kaardiTekst.setText(vastusNahtav ? kysimus + "\n\nVastus:\n" + vastus : kysimus);
    }

    private void alustaTesti(String teemaNimi, int tyypIndeks) {
        valitudTeema = teemaNimi;
        TestiTeema teema = testiAndmed.get(teemaNimi).get(tyypIndeks);
        valitudHarjutuseTyyp = vormindaTyyp(teema.getNimi());
        aktiivsedKysimused = new ArrayList<>(teema.getKysimused());
        testiVastused = new ArrayList<>();
        Collections.shuffle(aktiivsedKysimused);
        kysimuseIndeks = 0;
        punktid = 0;

        Label pealkiri = new Label(teemaNimi + " – " + valitudHarjutuseTyyp);
        pealkiri.getStyleClass().add("section-title");
        testiKysimusLabel = new Label();
        testiKysimusLabel.setWrapText(true);
        testiKysimusLabel.getStyleClass().add("question-text");
        vastuseVali = new TextField();
        vastuseVali.setPromptText("Kirjuta vastus siia ja vajuta Enter");
        vastuseVali.getStyleClass().add("answer-field");
        vastuseVali.setOnAction(e -> kontrolliVastus(teema));

        Button vasta = new Button("Vasta");
        vasta.getStyleClass().add("primary-button");
        vasta.setDefaultButton(true);
        vasta.setOnAction(e -> kontrolliVastus(teema));

        VBox kaart = new VBox(16, pealkiri, testiKysimusLabel, vastuseVali, vasta);
        kaart.getStyleClass().add("card-large");
        VBox.setVgrow(testiKysimusLabel, Priority.ALWAYS);

        StackPane sisu = new StackPane(kaart);
        sisu.getStyleClass().add("content-area");
        juur.setCenter(sisu);
        uuendaTestiKysimus();
        Platform.runLater(() -> vastuseVali.requestFocus());
    }

    /** Kontrollib kasutaja vastust ja käsitleb tühja vastuse erindina. */
    private void kontrolliVastus(TestiTeema teema) {
        try {
            String vastus = vastuseVali.getText();
            if (vastus == null || vastus.isBlank()) {
                throw new IllegalArgumentException("Vastus ei tohi olla tühi.");
            }

            Kusimus kysimus = aktiivsedKysimused.get(kysimuseIndeks);
            boolean oige = kysimus.kontrolliVastus(vastus);
            testiVastused.add(new TestiVastuseKirje(kysimus.getTekst(), vastus.trim(), kysimus.getOigeVastus(), oige));

            if (oige) {
                punktid++;
                naitaTeade("Õige vastus!");
            } else {
                naitaViga("Vale. Õige vastus: " + kysimus.getOigeVastus());
            }

            kysimuseIndeks++;
            vastuseVali.clear();

            if (kysimuseIndeks >= aktiivsedKysimused.size()) {
                lõpetaTest(teema);
            } else {
                uuendaTestiKysimus();
                Platform.runLater(() -> vastuseVali.requestFocus());
            }
        } catch (IllegalArgumentException ex) {
            naitaViga(ex.getMessage());
        } catch (Exception ex) {
            naitaViga("Vastuse kontrollimisel tekkis viga: " + ex.getMessage());
        }
    }

    private void uuendaTestiKysimus() {
        Kusimus kysimus = aktiivsedKysimused.get(kysimuseIndeks);
        testiKysimusLabel.setText("Küsimus " + (kysimuseIndeks + 1) + " / " + aktiivsedKysimused.size() + "\n\n" + kysimus.getTekst());
    }

    private void lõpetaTest(TestiTeema teema) {
        try {
            tulemusteHaldur.salvestaTulemus(valitudTeema, valitudHarjutuseTyyp, punktid, aktiivsedKysimused.size(), testiVastused);
            naitaTeade("Test lõpetatud! Tulemus salvestati faili.");
            naitaTulemusteNupp();
        } catch (IOException ex) {
            naitaViga("Tulemust ei õnnestunud faili salvestada: " + ex.getMessage());
        }

        Label tulemus = new Label("Test läbi!\n\nSinu tulemus: " + punktid + " / " + aktiivsedKysimused.size());
        tulemus.getStyleClass().add("result-title");

        Button uusTest = new Button("Tee uus test");
        uusTest.getStyleClass().add("secondary-button");
        uusTest.setOnAction(e -> kuvaValikuVaade(false));

        Button tulemused = new Button("Vaata tulemusi");
        tulemused.getStyleClass().add("primary-button");
        tulemused.setOnAction(e -> kuvaTulemusteVaade());

        VBox kaart = new VBox(20, tulemus, new HBox(12, uusTest, tulemused));
        kaart.getStyleClass().add("card-large");
        juur.setCenter(new StackPane(kaart));
    }

    private void kuvaTulemusteVaade() {
        juur.setCenter(looTulemusteVaade());
        peidaTulemusteNupp();
        naitaTeade("Klõpsa tulemusel kaks korda, et näha kogu läbitud testi.");
    }

    private Pane looTulemusteVaade() {
        ListView<TulemuseKirje> list = new ListView<>();
        list.getStyleClass().add("result-list");
        try {
            List<TulemuseKirje> tulemused = tulemusteHaldur.loeTulemused();
            if (tulemused.isEmpty()) {
                naitaTeade("Tulemusi ei ole veel salvestatud.");
            } else {
                list.getItems().addAll(tulemused);
            }
        } catch (Exception ex) {
            naitaViga("Tulemuste lugemisel tekkis viga: " + ex.getMessage());
        }

        list.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && list.getSelectionModel().getSelectedItem() != null) {
                avaTulemuseDetailid(list.getSelectionModel().getSelectedItem());
            }
        });

        Button ava = new Button("Ava valitud tulemus");
        ava.getStyleClass().add("primary-button");
        ava.setOnAction(e -> {
            TulemuseKirje valitud = list.getSelectionModel().getSelectedItem();
            if (valitud == null) naitaViga("Vali esmalt nimekirjast tulemus.");
            else avaTulemuseDetailid(valitud);
        });

        VBox kaart = new VBox(14, new Label("Varasemad tulemused"), list, ava);
        kaart.getStyleClass().add("card-large");
        VBox.setVgrow(list, Priority.ALWAYS);
        StackPane sisu = new StackPane(kaart);
        sisu.getStyleClass().add("content-area");
        return sisu;
    }

    /** Avab tulemuse detailid uues väikeses aknas. */
    private void avaTulemuseDetailid(TulemuseKirje kirje) {
        Stage aken = new Stage();
        aken.initModality(Modality.APPLICATION_MODAL);
        aken.setTitle("Läbitud testi detailid");

        Label pealkiri = new Label(kirje.getTeema() + " – " + kirje.getHarjutuseTyyp());
        pealkiri.getStyleClass().add("section-title");
        Label info = new Label(kirje.getAeg() + "   |   Tulemus: " + kirje.getPunktid() + " / " + kirje.getKokku());
        info.getStyleClass().add("muted-text");

        VBox vastusteKast = new VBox(12);
        List<TestiVastuseKirje> vastused = kirje.getVastused();
        if (vastused.isEmpty()) {
            Label puudub = new Label("Selle tulemuse kohta ei ole detailseid küsimusi salvestatud. Vanad tulemused sisaldavad ainult kokkuvõtet.");
            puudub.setWrapText(true);
            puudub.getStyleClass().add("card-text");
            vastusteKast.getChildren().add(puudub);
        } else {
            for (int i = 0; i < vastused.size(); i++) {
                vastusteKast.getChildren().add(looVastuseKaart(i + 1, vastused.get(i)));
            }
        }

        ScrollPane scroll = new ScrollPane(vastusteKast);
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("transparent-scroll");

        Button sulge = new Button("Sulge");
        sulge.getStyleClass().add("secondary-button");
        sulge.setOnAction(e -> aken.close());

        VBox sisu = new VBox(16, pealkiri, info, scroll, sulge);
        sisu.getStyleClass().add("content-area");
        sisu.setPadding(new Insets(18));

        Scene scene = new Scene(sisu, 720, 560);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/kujundus.css")).toExternalForm());
        aken.setScene(scene);
        aken.showAndWait();
    }

    private VBox looVastuseKaart(int nr, TestiVastuseKirje vastus) {
        Label tulemus = new Label(vastus.isOige() ? "Õige" : "Vale");
        tulemus.getStyleClass().add(vastus.isOige() ? "correct-pill" : "wrong-pill");

        Label kysimus = new Label(nr + ". " + vastus.getKysimus());
        kysimus.setWrapText(true);
        kysimus.getStyleClass().add("card-text");

        Label kasutajaVastus = new Label("Sinu vastus: " + vastus.getKasutajaVastus());
        kasutajaVastus.setWrapText(true);
        kasutajaVastus.getStyleClass().add("muted-text");

        Label oigeVastus = new Label("Õige vastus: " + vastus.getOigeVastus());
        oigeVastus.setWrapText(true);
        oigeVastus.getStyleClass().add("muted-text");

        HBox ylarida = new HBox(10, tulemus, kysimus);
        ylarida.setAlignment(Pos.CENTER_LEFT);
        VBox kaart = new VBox(8, ylarida, kasutajaVastus, oigeVastus);
        kaart.getStyleClass().add("answer-card");
        return kaart;
    }

    /** Klaviatuurisündmused: Escape avab avalehe, tühik/Enter juhib kordamiskaarte. */
    private void lisaKlaviatuuriOtseteed(Scene scene) {
        scene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                kuvaAvaleht();
                event.consume();
            } else if ((event.getCode() == KeyCode.SPACE || event.getCode() == KeyCode.ENTER)
                    && naitaVastusNupp != null && naitaVastusNupp.getScene() != null) {
                liiguKordamises();
                event.consume();
            }
        });
    }

    private void naitaTulemusteNupp() {
        vaataTulemusiNupp.setVisible(true);
        vaataTulemusiNupp.setManaged(true);
    }

    private void peidaTulemusteNupp() {
        vaataTulemusiNupp.setVisible(false);
        vaataTulemusiNupp.setManaged(false);
    }

    private void naitaTeade(String tekst) {
        olekuTekst.setText(tekst);
        olekuTekst.getStyleClass().removeAll("status-error");
        if (!olekuTekst.getStyleClass().contains("status-text")) olekuTekst.getStyleClass().add("status-text");
    }

    private void naitaViga(String tekst) {
        olekuTekst.setText("Viga: " + tekst);
        if (!olekuTekst.getStyleClass().contains("status-error")) olekuTekst.getStyleClass().add("status-error");
    }
}
