package com.example.oop_graafika;

/**
 * Lihtne käivitusklass. Seda klassi võib IntelliJ-s rohelise Run-nupuga käivitada.
 */
public class Main {
    public static void main(String[] args) {
        javafx.application.Application.launch(GraafilineRakendus.class, args);
    }
}
