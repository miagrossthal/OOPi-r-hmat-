package com.example.oop_graafika;

/** Liides objektidele, mida saab tekstina ekraanile kuvada. */
public interface Kuvatav {
    void kuva();
}
