package com.example.oop_graafika;

/**
 * Hoiab ühe testiküsimuse vastamise infot.
 * Seda kasutatakse selleks, et tulemuste failist saaks hiljem avada kogu läbitud testi.
 */
public class TestiVastuseKirje {
    private final String kysimus;
    private final String kasutajaVastus;
    private final String oigeVastus;
    private final boolean oige;

    public TestiVastuseKirje(String kysimus, String kasutajaVastus, String oigeVastus, boolean oige) {
        this.kysimus = kysimus;
        this.kasutajaVastus = kasutajaVastus;
        this.oigeVastus = oigeVastus;
        this.oige = oige;
    }

    public String getKysimus() { return kysimus; }
    public String getKasutajaVastus() { return kasutajaVastus; }
    public String getOigeVastus() { return oigeVastus; }
    public boolean isOige() { return oige; }
}
