package com.example.oop_graafika;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Tegeleb tulemuste faili kirjutamise ja lugemisega. */
public class TulemusteHaldur {
    private static final Path FAILI_TEE = Path.of("tulemused.csv");
    private static final DateTimeFormatter FORMAAT = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    public void salvestaTulemus(String teema, String harjutuseTyyp, int punktid, int kokku,
                                List<TestiVastuseKirje> vastused) throws IOException {
        String aeg = LocalDateTime.now().format(FORMAAT);
        TulemuseKirje kirje = new TulemuseKirje(aeg, teema, harjutuseTyyp, punktid, kokku, vastused);
        Files.writeString(FAILI_TEE, kirje.vormindaFailiReaks() + System.lineSeparator(),
                StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    public List<TulemuseKirje> loeTulemused() throws IOException {
        List<TulemuseKirje> tulemused = new ArrayList<>();
        if (!Files.exists(FAILI_TEE)) return tulemused;
        for (String rida : Files.readAllLines(FAILI_TEE, StandardCharsets.UTF_8)) {
            if (!rida.isBlank()) tulemused.add(TulemuseKirje.loeFailiReast(rida));
        }
        return tulemused;
    }
}
