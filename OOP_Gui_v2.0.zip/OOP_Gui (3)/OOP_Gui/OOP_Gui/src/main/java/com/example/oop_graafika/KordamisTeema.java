package com.example.oop_graafika;

/** Kordamise teema koos kokkuvõtte/kaartidega. */
public class KordamisTeema extends Teema {
    private String kokkuvote;

    public KordamisTeema(String nimi, String kirjeldus, String kokkuvote) {
        super(nimi, kirjeldus);
        this.kokkuvote = kokkuvote;
    }

    public String getKokkuvote() { return kokkuvote; }

    @Override
    public void kuva() {
        System.out.println(nimi + "\n" + kokkuvote);
    }
}
