package com.example.oop_graafika;

import java.util.List;

/** Testiteema, mille all on mitu küsimust. */
public class TestiTeema extends Teema {
    private final List<Kusimus> kysimused;

    public TestiTeema(String nimi, String kirjeldus, List<Kusimus> kysimused) {
        super(nimi, kirjeldus);
        this.kysimused = kysimused;
    }

    public List<Kusimus> getKysimused() { return kysimused; }

    @Override
    public void kuva() {
        System.out.println(nimi);
    }
}
