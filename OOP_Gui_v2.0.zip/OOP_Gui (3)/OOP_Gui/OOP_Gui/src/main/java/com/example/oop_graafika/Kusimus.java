package com.example.oop_graafika;

/** Abstraktne baasklass küsimustele. */
public abstract class Kusimus implements Kuvatav {
    protected String tekst;
    protected String oigeVastus;

    public Kusimus(String tekst, String oigeVastus) {
        this.tekst = tekst;
        this.oigeVastus = oigeVastus;
    }

    public String getTekst() { return tekst; }
    public String getOigeVastus() { return oigeVastus; }

    /** Kontrollib vastust, lubades väikseid erinevusi suur- ja väiketähtedes. */
    public boolean kontrolliVastus(String vastus) {
        if (vastus == null) return false;
        return oigeVastus.trim().equalsIgnoreCase(vastus.trim());
    }
}
