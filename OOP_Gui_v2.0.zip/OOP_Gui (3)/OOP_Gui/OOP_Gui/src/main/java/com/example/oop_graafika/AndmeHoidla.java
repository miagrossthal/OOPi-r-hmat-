package com.example.oop_graafika;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Loeb õppematerjali .txt failidest.
 * Failid asuvad kaustas src/main/resources, seega neid saab lugeda ka JAR-failist.
 */
public class AndmeHoidla {

    /** Loeb failist testiküsimused ja grupeerib need tüübi järgi teemadeks. */
    public static List<TestiTeema> looTestiTeemad(String failiNimi) {
        List<TestiTeema> teemad = new ArrayList<>();
        for (KusimuseKirje kirje : loeKirjed(failiNimi)) {
            Kusimus kusimus = new TekstKusimus(kirje.kysimus, kirje.vastus);
            lisaKusimusTeemasse(teemad, kirje.tyyp, kusimus);
        }
        return teemad;
    }

    /** Loeb failist kordamiskaardid. Iga kaart sisaldab küsimust ja vastust. */
    public static List<KordamisTeema> looKordamiseTeemad(String failiNimi) {
        List<KordamisTeema> teemad = new ArrayList<>();
        for (KusimuseKirje kirje : loeKirjed(failiNimi)) {
            String kokkuvote = kirje.kysimus + "\n" + kirje.vastus;
            lisaKordamisTeemasse(teemad, kirje.tyyp, kokkuvote);
        }
        return teemad;
    }

    /** Loeb kõik kirjed ühest tekstifailist. */
    private static List<KusimuseKirje> loeKirjed(String failiNimi) {
        List<KusimuseKirje> kirjed = new ArrayList<>();

        InputStream sisend = AndmeHoidla.class.getResourceAsStream("/" + failiNimi);
        if (sisend == null) {
            throw new IllegalArgumentException("Faili ei leitud resources kaustast: " + failiNimi);
        }

        try (Scanner sc = new Scanner(sisend, StandardCharsets.UTF_8)) {
            String tyyp = "ÜLDINE";
            StringBuilder kysimus = new StringBuilder();
            StringBuilder vastus = new StringBuilder();
            String aktiivneVali = "";

            while (sc.hasNextLine()) {
                String rida = sc.nextLine();
                String trimmitud = rida.trim();

                if (trimmitud.equals("---")) {
                    lisaKirjeKuiVõimalik(kirjed, tyyp, kysimus, vastus);
                    kysimus.setLength(0);
                    vastus.setLength(0);
                    aktiivneVali = "";
                } else if (trimmitud.startsWith("TÜÜP:")) {
                    tyyp = trimmitud.substring(5).trim();
                    aktiivneVali = "tyyp";
                } else if (trimmitud.startsWith("KÜSIMUS:")) {
                    kysimus.append(trimmitud.substring(8).trim());
                    aktiivneVali = "kysimus";
                } else if (trimmitud.startsWith("VASTUS:")) {
                    vastus.append(trimmitud.substring(7).trim());
                    aktiivneVali = "vastus";
                } else if (!trimmitud.isEmpty()) {
                    if (aktiivneVali.equals("kysimus")) kysimus.append("\n").append(rida);
                    if (aktiivneVali.equals("vastus")) vastus.append("\n").append(rida);
                }
            }
            lisaKirjeKuiVõimalik(kirjed, tyyp, kysimus, vastus);
        }
        return kirjed;
    }

    private static void lisaKirjeKuiVõimalik(List<KusimuseKirje> kirjed, String tyyp,
                                            StringBuilder kysimus, StringBuilder vastus) {
        if (!kysimus.toString().isBlank() && !vastus.toString().isBlank()) {
            kirjed.add(new KusimuseKirje(tyyp, kysimus.toString().trim(), vastus.toString().trim()));
        }
    }

    private static void lisaKusimusTeemasse(List<TestiTeema> teemad, String tyyp, Kusimus kusimus) {
        for (TestiTeema teema : teemad) {
            if (teema.getNimi().equals(tyyp)) {
                teema.getKysimused().add(kusimus);
                return;
            }
        }
        List<Kusimus> kysimused = new ArrayList<>();
        kysimused.add(kusimus);
        teemad.add(new TestiTeema(tyyp, "Automaatselt failist loodud teema", kysimused));
    }

    private static void lisaKordamisTeemasse(List<KordamisTeema> teemad, String tyyp, String kaart) {
        for (int i = 0; i < teemad.size(); i++) {
            KordamisTeema vana = teemad.get(i);
            if (vana.getNimi().equals(tyyp)) {
                teemad.set(i, new KordamisTeema(vana.getNimi(), vana.getKirjeldus(), vana.getKokkuvote() + "\n\n" + kaart));
                return;
            }
        }
        teemad.add(new KordamisTeema(tyyp, "Automaatselt failist loodud teema", kaart));
    }

    /** Väike abiklass ühe failist loetud küsimuse hoidmiseks. */
    private record KusimuseKirje(String tyyp, String kysimus, String vastus) { }
}
