rootProject.name = "oop_graafika_korras"
